  <?php include 'header.php'; ?>

  <!-- Contact Header -->
  <?php include 'parts/common/header-section.php' ?>
  <!-- End Contact Header -->

  <!-- Contact Section -->
  <?php include 'parts/contact/contact-section.php' ?>
  <!-- End Contact Section -->

  <!-- Map Section -->
  <?php include 'parts/contact/map.php' ?>
  <!-- End Map Section -->

  <!-- Additional Info Section -->
  <?php include 'parts/contact/additional-info.php' ?>
  <!-- End Additional Info Section -->

  <?php include 'footer.php'; ?>