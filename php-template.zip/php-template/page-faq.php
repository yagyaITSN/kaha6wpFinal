<?php include 'header.php'; ?>

<!-- FAQ Header -->
<?php include 'parts/common/header-section.php' ?>
<!-- End FAQ Header -->

<!-- FAQ Section -->
<?php include 'parts/faq/qa.php' ?>
<!-- End FAQ Section -->

<!-- More Help Section -->
<?php include 'parts/faq/help.php' ?>
<!-- End More Help Section -->

<?php include 'footer.php'; ?>