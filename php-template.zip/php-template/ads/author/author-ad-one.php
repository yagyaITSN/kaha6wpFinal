<div class="itsn-container">
   <div class="itsn-box text-align d-flex align-items-center justify-content-center shadow-sm border-0 rounded-1"
      style="width: 100%; height: auto; min-height: 200px;">
      Replace with Responsive Ad (Google Auto Ads)
   </div>
</div>