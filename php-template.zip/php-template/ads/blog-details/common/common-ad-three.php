<div class="itsn-container">
   <div class="itsn-box text-align d-flex align-items-center justify-content-center"
      style="width: 300px; height: 600px; margin: auto; overflow: hidden;">
      Replace with Ad Code (300×600)
   </div>
</div>