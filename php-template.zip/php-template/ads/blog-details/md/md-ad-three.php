<div class="itsn-container my-3 d-none d-md-block">
   <div class="itsn-box text-align d-flex align-items-center justify-content-center"
      style="width: 728px; height: 90px; margin: auto; overflow: hidden;">
      Replace with AdSense/Ad Code (728×90)
   </div>
</div>