<div class="itsn-container mb-lg-3">
   <div class="itsn-box text-align d-flex align-items-center justify-content-center"
      style="width: 300px; height: 250px; margin: auto; overflow: hidden;">
      Replace with Ad Code (300×250)
   </div>
</div>