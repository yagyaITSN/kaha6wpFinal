<section class="itsn-container container mt-5">
   <div class="itsn-box text-align d-flex align-items-center justify-content-center shadow-sm border-0 rounded-1"
      style="width: 100%; height: auto; min-height: 100px;">
      Replace with Responsive Ad (Google Auto Ads)
   </div>
</section>