<?php include 'header.php'; ?>

<!-- Author Hero Section -->
<?php include 'parts/author/author-hero.php'; ?>
<!-- End Author Hero Section -->

<!-- Author Added Businesses -->
<?php include 'parts/author/business-list.php' ?>
<!-- End Author Added Businesses -->

<!-- Banner  -->
<?php include 'ads/author/author-ad-two.php'; ?>
<!-- End Banner  -->

<?php include 'footer.php'; ?>