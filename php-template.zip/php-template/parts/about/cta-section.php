<section class="container cta-section shadow-sm border-0 rounded-4 text-center py-5 my-5">
   <h2 class="fs-2 fw-bold">Ready to Boost Your Business?</h2>
   <p class="lead my-3">Join the KAHA6 Directory portal today and navigate customers straight to your business
   </p>
   <a href="./page-register.php" class="btn btn-custom-red btn-lg px-5">List
      Your Business Now</a>
</section>