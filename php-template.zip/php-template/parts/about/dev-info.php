<section class="container developed-info py-5">
   <div class="text-center">
      <h2 class="fs-2 fw-bold">Our Technology</h2>
      <p>kaha6.com Web Directory is proudly developed by:</p>
      <div class="d-inline-block shadow-sm border-0 rounded-4 p-md-4 p-2 text-center">
         <a href="https://itservicenepal.com/?ref=kaha6.com" class="mb-0 d-flex flex-column"><img
               src="https://itservicenepal.com/wp-content/themes/ITSN/images/it-service-nepal-logo.svg"
               alt="IT Service Nepal Logo" height="50" class="mb-2">
            IT Service Nepal
         </a>
      </div>
   </div>
</section>