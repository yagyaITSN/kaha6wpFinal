<section class="container contact-cta shadow-sm border-0 rounded-4 text-center py-5 mb-5">
   <h2 class="fs-2 fw-bold">Still have questions?</h2>
   <p class="lead my-3">Our support team is ready to help you with any questions about our business directory.
   </p>
   <a href="https://kaha6.com/contact/" class="btn btn-custom-red btn-lg px-5">Contact Support</a>
</section>