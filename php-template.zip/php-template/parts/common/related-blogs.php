<section class="related-card-section container py-5">
   <h2 class="fs-2 fw-bold border-start border-4 border-danger ps-3 mb-4">Related Blogs</h2>
   <div class="related-card-slider swiper mySwiper">
      <div class="swiper-wrapper py-5">
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital Lorem ipsum dolor
                  sit amet consectetur.
               </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
         <a href="./single-blog.php"
            class="swiper-slide card shadow-sm border-0 text-decoration-none rounded-4 overflow-hidden">
            <img src="https://kaha6.com/wp-content/uploads/bhc-no-bg-circle-logo.png" class="card-img-top"
               alt="Birgunj Health Care hospital">
            <div class="card-body d-flex flex-column justify-content-between">
               <h5 class="card-title text-dark text-capitalize">Birgunj Health Care Hospital </h5>
               <div class="card-tags d-flex justify-content-between flex-wrap gap-2">
                  <span class="badge text-dark text-capitalize">Category</span>
                  <span class="badge text-dark text-capitalize">Comments(0)</span>
               </div>
            </div>
         </a>
      </div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
   </div>
</section>