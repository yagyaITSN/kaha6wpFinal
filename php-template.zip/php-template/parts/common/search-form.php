<form method="GET" action="https://kaha6.com/"
   class="search-form shadow-sm border-0 rounded-4 bg-white p-3 p-md-4">
   <div class="row g-2 align-items-center">
      <div class="col-12 col-md-3">
         <input type="text" name="s" class="form-control" placeholder="Business Name"
            value="">
      </div>
      <div class="col-12 col-md-3">
         <input type="text" name="business-type" class="form-control"
            placeholder="Business Type" value="" list="business-type-list">
         <datalist id="business-type-list">
            <option value="Advertising"></option>
            <option value="Agriculture"></option>
            <option value="wires Manufacturer"></option>
            <option value="Woman"> </option>
         </datalist>
      </div>
      <div class="col-12 col-md-3">
         <input type="text" name="location" class="form-control" placeholder="Location"
            value="" list="location-list">
         <datalist id="location-list">
            <option value="Aathbiskot"></option>
            <option value="Urlabari"></option>
            <option value="Waling"> </option>
         </datalist>
      </div>
      <div class="col-12 col-md-3">
         <button type="submit" class="btn btn-custom-red w-100 py-2">Search</button>
      </div>
   </div>
</form>